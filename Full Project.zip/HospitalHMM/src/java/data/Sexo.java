/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package data;
/**
 * Clase que permite definir el genero para la clase empleado
 * @author Diego Ricardo Montoya Baez
 * @version 1.0
 */
public enum Sexo {
    Masculino, Femenino, Otro
}
